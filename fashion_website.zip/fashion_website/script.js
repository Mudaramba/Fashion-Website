let cart = JSON.parse(localStorage.getItem('cart')) || [];

function saveCart(){ localStorage.setItem('cart', JSON.stringify(cart)); }

function addToCart(name, price){
  cart.push({name, price});
  saveCart();
  renderCart();
}

function removeItem(index){
  cart.splice(index,1);
  saveCart();
  renderCart();
}

function clearCart(){
  cart=[];
  saveCart();
  renderCart();
}

function renderCart(){
  const items = document.getElementById('cart-items');
  const total = document.getElementById('cart-total');
  if(!items) return;

  items.innerHTML='';
  let sum=0;

  cart.forEach((item,i)=>{
    sum+=item.price;
    items.innerHTML+=`<div>${item.name} $${item.price} <button onclick="removeItem(${i})">X</button></div>`;
  });

  total.innerText = 'Total: $'+sum;
}

renderCart();
